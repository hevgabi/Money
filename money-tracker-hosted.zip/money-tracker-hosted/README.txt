Money Tracker (hosted)

This folder is ready for static hosting (GitHub Pages / Netlify / Cloudflare Pages).
Main file: index.html

Quick GitHub Pages:
1) Create a new GitHub repo
2) Upload index.html
3) Settings -> Pages -> Deploy from branch -> main / root
4) Open the provided URL.
